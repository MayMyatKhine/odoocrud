# -*- coding: utf-8 -*-

from openerp import models, fields, api

# class inherit_report_demo(models.Model):
#     _name = 'inherit_report_demo.inherit_report_demo'

#     name = fields.Char()
#     value = fields.Integer()
#     value2 = fields.Float(compute="_value_pc", store=True)
#     description = fields.Text()
#
#     @api.depends('value')
#     def _value_pc(self):
#         self.value2 = float(self.value) / 100